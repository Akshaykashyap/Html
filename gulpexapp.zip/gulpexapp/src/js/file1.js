//console log 1
console.log('This is file 1439499349409kksfkdklksdfk');

//console log 2
alert("hello guysdksdkkdsklfkdkls");

alert('This is another file 2kdskdkdksdkkdkdlkdf');