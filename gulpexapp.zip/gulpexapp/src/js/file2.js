//console.log

console.log('This is file 2kdkdk');

//Alert

alert('This is file 2dkslklkdfkdskkfkfdssdfd');
 
 alert('this is awesome file in gulp sass');